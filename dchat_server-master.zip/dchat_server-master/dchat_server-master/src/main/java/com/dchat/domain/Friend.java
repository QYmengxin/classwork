package com.dchat.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 好友记录
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
public class Friend {
    @TableId(type = IdType.AUTO)
    private Integer id;
    private Integer id1;
    private Integer id2;
    private String time;
}
