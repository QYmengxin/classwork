package com.dchat.service.inter;

import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dchat.domain.Blog;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public interface BlogService {
    @Async
    void insert(Blog blog);
    Page<Blog> getByPage(Integer pageNum);
    Page<Blog> getByPageById(Integer pageNum,Integer id);

    @Async
    void delete(Integer blogId,Integer userId);

    Blog getOne(Integer blogId);

}
