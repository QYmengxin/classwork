package com.dchat.util;

import java.text.SimpleDateFormat;

public class MyDateUtil {
    public static SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
}
