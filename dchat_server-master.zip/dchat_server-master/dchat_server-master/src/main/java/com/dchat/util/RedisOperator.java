package com.dchat.util;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 *
 * 对redis的操作 封装
 */
@Component
public class RedisOperator {
    @Autowired
    private RedisTemplate<Object,Object> redisTemplate;

    /**
     * 缓存群成员的id
     */
//    @Async
    public void cacheMemberId(String groupId,List<Integer> memberIds){
        redisTemplate.opsForHash().put("member:"+groupId,"ids",memberIds);
    }
    /**
     * 清除群成员信息
     */
    @Async
    public void clearMemberId(String groupId){
        redisTemplate.opsForHash().delete("member:"+groupId,"ids");
    }
    /**
     * 获取缓存群成员id
     */
    public Object getCacheMemberId(String groupId){
        return redisTemplate.opsForHash().get("member:"+groupId,"ids");
    }
    /**
     * 获取一个群id
     */
    public String getGroupId(){
        redisTemplate.opsForValue().setIfAbsent("groupId",0);
        redisTemplate.opsForValue().increment("groupId");
        return "g"+redisTemplate.opsForValue().get("groupId");
    }
    /**
     * 验证token
     */
    public Integer verifyToken(String token){
        return (Integer) redisTemplate.opsForHash().get("token:"+token,"token"); //token失效
    }
    /**
     * 设置token
     */
    @Async
    public void setToken(String token,Integer id){
        //设置token
        redisTemplate.opsForHash().put("token:"+token, "token", id);
        //设置过期时间
        redisTemplate.expire("token:"+token,7, TimeUnit.DAYS);
    }

    /**
     * 缓存用户消息
     */
    @Async
    public void cacheMessages(String id, String message){
        redisTemplate.opsForList().rightPush("message:"+id,message);
    }
    /**
     * 根据用户id获取消息缓存
     */
    public List<Object> getCacheMessages(String id){
        /*
        Long len = redisTemplate.opsForList().size("message:"+id);
        len = len == null ? 0 :len;
        return redisTemplate.opsForList().leftPop("message:"+id,len);
        */
        List<Object> messages =  redisTemplate.opsForList().range("message:"+id,0,-1);
        redisTemplate.delete("message:"+id);
        return messages;
    }

    /**
     * 缓存公共聊天室的消息
     */
    @Async
    public void cacheLobbyMessage(String message){
        redisTemplate.opsForList().rightPush("lobby",message);
        Long len = redisTemplate.opsForList().size("lobby");
        //只保存100条记录
        if (len>99) {
            redisTemplate.opsForList().leftPop("lobby");
        }
    }

    /**
     * 获取公共聊天室缓存消息
     * @return
     */
    public List<Object> getCacheLobbyMessages(){
        return redisTemplate.opsForList().range("lobby",0,-1);
    }

    /**
     * 给说说点赞
     */
    public void likeBlog(String blogId,String userId){
        redisTemplate.opsForList().rightPush("blog:"+blogId,userId);
    }
    /**
     * 获取点赞的人
     */
    public List<Object> getBlogLike(String blogId){
        return redisTemplate.opsForList().range("blog:"+blogId,0,-1);
    }
    /**
     * 删除说说点赞记录
     */
    @Async
    public void clearLikes(Integer blogId){
        redisTemplate.delete("blog:"+blogId);
    }
}
