package com.dchat.service.imp;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.dchat.domain.Comment;
import com.dchat.mapper.CommentMapper;
import com.dchat.service.inter.CommentService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class CommentServiceImp implements CommentService {
    @Autowired
    private CommentMapper commentMapper;

    @Override
    public void insert(Comment comment) {
        commentMapper.insert(comment);
    }

    @Override
    public List<Comment> getComments(Integer blogId) {
        QueryWrapper<Comment> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("blog_id",blogId).orderByAsc("id");
        return commentMapper.selectList(queryWrapper);
    }

    @Override
    @Async
    public void deleteByBlogId(Integer id) {
        QueryWrapper<Comment> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("blog_id",id);
        commentMapper.delete(queryWrapper);
    }

    @Override
    public void deleteById(Integer id) {
        QueryWrapper<Comment> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("id",id);
        commentMapper.delete(queryWrapper);
    }
}
