package com.dchat.controller;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.dchat.domain.Grouper;
import com.dchat.domain.Member;
import com.dchat.domain.ResponseDto;
import com.dchat.service.inter.GroupService;
import com.dchat.service.inter.MemberService;
import com.dchat.util.MyDateUtil;
import com.dchat.util.RedisOperator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Date;
import java.util.List;

@RestController
@RequestMapping("/dchat")
public class GroupController {

    @Autowired
    private RedisOperator redisOperator;
    @Autowired
    private GroupService groupService;
    @Autowired
    private MemberService memberService;

    @PostMapping("updateGroup")
    public String updateGroup(@RequestBody String data){
        JSONObject jsonObject = JSONUtil.parseObj(data);
        //验证token是否存在或者失效
        Integer id = redisOperator.verifyToken(jsonObject.getStr("token"));
        if(id==null) {
            return JSONUtil.toJsonStr(new ResponseDto<String>(false, 404, "token失效或者未找到"));
        }
        String groupId = jsonObject.getStr("groupId");
        String name = jsonObject.getStr("name");
        String introduction = jsonObject.getStr("introduction");
        String avatar = jsonObject.getStr("avatar");
        Grouper grouper = new Grouper(groupId,name,avatar,null,null,introduction);
        groupService.updateOne(grouper);
        return JSONUtil.toJsonStr(new ResponseDto<>("修改成功"));
    }

    @PostMapping("/findGroup")
    public String findGroup(@RequestBody String data){
        JSONObject jsonObject = JSONUtil.parseObj(data);
        String keyword = jsonObject.getStr("keyword");
        keyword = keyword.replaceAll("%","\\\\%").replaceAll("_","\\\\_");
        List<Grouper> list = groupService.getByKeyword(keyword);
        return JSONUtil.toJsonStr(new ResponseDto<>(list));
    }

    @PostMapping("/getGroup")
    public String getGroup(@RequestBody String data){
        JSONObject jsonObject = JSONUtil.parseObj(data);
        //验证token是否存在或者失效
        Integer id = redisOperator.verifyToken(jsonObject.getStr("token"));
        if(id==null) {
            return JSONUtil.toJsonStr(new ResponseDto<String>(false, 404, "token失效或者未找到"));
        }
        return JSONUtil.toJsonStr(new ResponseDto<>(groupService.getByMemberId(id)));
    }
    @PostMapping("/createGroup")
    public String createGroup(@RequestBody String data){
        JSONObject jsonObject = JSONUtil.parseObj(data);
        //验证token是否存在或者失效
        Integer id = redisOperator.verifyToken(jsonObject.getStr("token"));
        if(id==null) {
            return JSONUtil.toJsonStr(new ResponseDto<String>(false, 404, "token失效或者未找到"));
        }
        //开始建群
        String gid = redisOperator.getGroupId();
        String date = MyDateUtil.simpleDateFormat.format(new Date());
        Grouper group = new Grouper(
                gid,
                jsonObject.getStr("name"),
                jsonObject.getStr("avatar"),
                id,
                date,
                jsonObject.getStr("introduction")
        );

        groupService.insertOne(group);

        memberService.insertOne(new Member(null, gid, id, date));

        return JSONUtil.toJsonStr(new ResponseDto<>(group));
    }
}
