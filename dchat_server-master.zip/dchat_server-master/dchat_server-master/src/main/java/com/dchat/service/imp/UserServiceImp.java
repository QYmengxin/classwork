package com.dchat.service.imp;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.dchat.domain.User;
import com.dchat.mapper.UserMapper;
import com.dchat.service.inter.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class UserServiceImp implements UserService {
    @Autowired
    private UserMapper userMapper;


    @Override
    public User getUserByLoginId(String loginId) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.eq("login_id",loginId);
        return userMapper.selectOne(wrapper);
    }

    @Override
    public User getUserById(Integer id) {
        return userMapper.selectById(id);
    }

    @Override
    public void updateUserById(User user) {
       userMapper.updateById(user);
    }

    @Override
    @Async
    public void updateAvatar(User user) {
        userMapper.updateById(user);
    }

    //新用户
    @Override
    @Async
    public void insertOne(User user) {
        userMapper.insert(user);
    }

    @Override
    public List<User> selectByKeyword(String keyword) {
        QueryWrapper<User> wrapper = new QueryWrapper<>();
        wrapper.like("login_id",keyword).or().like("nickname",keyword);
        return userMapper.selectList(wrapper);
    }
}
