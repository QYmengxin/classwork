package com.dchat.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dchat.domain.Comment;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

@Mapper
@Repository
public interface CommentMapper extends BaseMapper<Comment> {
}
