package com.dchat.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class UserInfo {
    private Integer id;
    private String loginId;
    private String nickname = "";
    private String avatar = "";
    private String gender = "";
    private String signature = "";
    private String registerTime = "";

    public UserInfo(User user){
        this.id = user.getId();
        this.loginId = user.getLoginId();
        this.nickname = user.getNickname();
        this.avatar = user.getAvatar();
        this.gender = user.getGender();
        this.signature = user.getSignature();
        if(user.getRegisterTime()==null){
            this.registerTime = "";
        }else this.registerTime = user.getRegisterTime();
    }
}
