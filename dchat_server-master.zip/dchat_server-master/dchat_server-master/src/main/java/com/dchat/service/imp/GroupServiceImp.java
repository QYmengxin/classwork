package com.dchat.service.imp;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.dchat.domain.Grouper;
import com.dchat.mapper.GroupMapper;
import com.dchat.service.inter.GroupService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class GroupServiceImp implements GroupService {
    @Autowired
    private GroupMapper groupMapper;

    @Override
    @Async
    public void insertOne(Grouper group) {
        groupMapper.insert(group);
    }

    @Override
    public List<Grouper> getByMemberId(Integer id) {
        return groupMapper.getByMemberId(id);
    }

    @Override
    public List<Grouper> getByKeyword(String keyword) {
        QueryWrapper<Grouper> grouperQueryWrapper = new QueryWrapper<>();
        grouperQueryWrapper.eq("id",keyword).or().like("name",keyword);
        return groupMapper.selectList(grouperQueryWrapper);
    }

    @Override
    @Async
    public void deleteOne(String id) {
        groupMapper.deleteById(id);
    }

    @Override
    public void updateOne(Grouper grouper) {
        groupMapper.updateById(grouper);
    }
}
