package com.dchat.domain;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Grouper {
    private String id;
    private String name;
    private String avatar;
    private Integer ownerId;
    private String createTime;
    private String introduction;
}
