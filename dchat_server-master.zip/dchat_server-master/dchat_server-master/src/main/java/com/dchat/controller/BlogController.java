package com.dchat.controller;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.dchat.domain.Blog;
import com.dchat.domain.Comment;
import com.dchat.domain.ResponseDto;
import com.dchat.service.inter.BlogService;
import com.dchat.service.inter.CommentService;
import com.dchat.util.RedisOperator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;



@RestController
@RequestMapping("/dchat/blog")
public class BlogController {
    @Autowired
    private RedisOperator redisOperator;
    @Autowired
    private BlogService blogService;
    @Autowired
    private CommentService commentService;
    /**
     * 发布说说
     */
    @PostMapping("/deliver")
    public String deliver(@RequestBody String data){
        JSONObject jsonObject = JSONUtil.parseObj(data);
        //验证token是否存在或者失效
        Integer id = redisOperator.verifyToken(jsonObject.getStr("token"));
        if(id==null) {
            return JSONUtil.toJsonStr(new ResponseDto<String>(false, 404, "token失效或者未找到"));
        }

        String content = jsonObject.getStr("content");
        String images = jsonObject.getStr("images");
        String time = jsonObject.getStr("time");
        if(((content==null||content.equals(" "))&&(images==null||images.equals("")))){
            return JSONUtil.toJsonStr(new ResponseDto<String>(false, 405, "内容太少"));
        }

        Blog blog = new Blog(null, id, time,content,images);
        blogService.insert(blog);
        return JSONUtil.toJsonStr(new ResponseDto<>("发布成功！"));
    }
    /**
     * 获取某一条说说以及评论 以及
     */
    @PostMapping("/getDetail")
    public String getDetail(@RequestBody String data){
        JSONObject jsonObject = JSONUtil.parseObj(data);
        String blogId = jsonObject.getStr("blogId");
        JSONObject rs = new JSONObject();
        rs.put("blog",blogService.getOne(Integer.valueOf(blogId)));
        rs.put("comments",commentService.getComments(Integer.valueOf(blogId)));
        rs.put("likes",redisOperator.getBlogLike(blogId));
        return JSONUtil.toJsonStr(new ResponseDto<>(rs));
    }
    /**
     * 以分页的方式获取说说
     */
    @PostMapping("/get")
    public String getBlog(@RequestBody String data){
        JSONObject jsonObject = JSONUtil.parseObj(data);
        String pageNum =jsonObject.getStr("pageNum");
        if(pageNum==null){
            return JSONUtil.toJsonStr(new ResponseDto<String>(false, 405, "缺少pageNum"));
        }
        return JSONUtil.toJsonStr(new ResponseDto<>(blogService.getByPage(Integer.valueOf(pageNum))));
    }

    /**
     * 给说说点赞
     */
    @PostMapping("/like")
    public String likeBlog(@RequestBody String data){
        JSONObject jsonObject = JSONUtil.parseObj(data);
        //验证token是否存在或者失效
        Integer id = redisOperator.verifyToken(jsonObject.getStr("token"));
        if(id==null) {
            return JSONUtil.toJsonStr(new ResponseDto<String>(false, 404, "token失效或者未找到"));
        }
        String blogId = jsonObject.getStr("blogId");
        redisOperator.likeBlog(blogId,String.valueOf(id));
        return JSONUtil.toJsonStr(new ResponseDto<>("点赞成功！"));
    }
    /**
     * 获取某个博客的点赞
     */
    @PostMapping("getLikes")
    public String getLikes(@RequestBody String data){
        JSONObject jsonObject = JSONUtil.parseObj(data);
        String blogId = jsonObject.getStr("blogId");
        return JSONUtil.toJsonStr(new ResponseDto<>(redisOperator.getBlogLike(blogId)));
    }

    /**
     * 发布评论
     */
    @PostMapping("/comment")
    public String comment(@RequestBody String data){
        JSONObject jsonObject = JSONUtil.parseObj(data);
        //验证token是否存在或者失效
        Integer id = redisOperator.verifyToken(jsonObject.getStr("token"));
        if(id==null) {
            return JSONUtil.toJsonStr(new ResponseDto<String>(false, 404, "token失效或者未找到"));
        }
        String blogId = jsonObject.getStr("blogId");
        String fatherId = jsonObject.getStr("fatherId");
        String fatherName = jsonObject.getStr("fatherName");
        String deliverName = jsonObject.getStr("deliverName");
        String content = jsonObject.getStr("content");
        String time = jsonObject.getStr("time");
        if (content.replaceAll(" ","").equals("")) {
            return JSONUtil.toJsonStr(new ResponseDto<String>(false, 405, "评论不能为空"));
        }
        Comment comment = new Comment(null,Integer.valueOf(blogId),Integer.valueOf(fatherId),fatherName,id,deliverName,content.replaceAll("\\n"," "),time);
        commentService.insert(comment);
        return JSONUtil.toJsonStr(new ResponseDto<>("评论成功！"));
    }

    /**
     * 获取某个博客的评论
     */
    @PostMapping("/getComments")
    public String getComments(@RequestBody String data){
        JSONObject jsonObject = JSONUtil.parseObj(data);
        String blogId = jsonObject.getStr("blogId");
        return JSONUtil.toJsonStr(new ResponseDto<>(commentService.getComments(Integer.valueOf(blogId))));
    }
    /**
     * 删除某一条评论
     */
    @PostMapping("/deleteComment")
    public String deleteComment(@RequestBody String data){
        JSONObject jsonObject = JSONUtil.parseObj(data);
        //验证token是否存在或者失效
        Integer id = redisOperator.verifyToken(jsonObject.getStr("token"));
        if(id==null) {
            return JSONUtil.toJsonStr(new ResponseDto<String>(false, 404, "token失效或者未找到"));
        }
        String commentId = jsonObject.getStr("commentId");
        commentService.deleteById(Integer.valueOf(commentId));
        return JSONUtil.toJsonStr(new ResponseDto<>("删除成功！"));
    }

    /**
     * 获取某一用户的博客
     */
    @PostMapping("/getOne")
    public String getBlogById(@RequestBody String data){
        JSONObject jsonObject = JSONUtil.parseObj(data);
        String userId = jsonObject.getStr("userId");
        String pageNum = jsonObject.getStr("pageNum");
        if(pageNum==null){
            return JSONUtil.toJsonStr(new ResponseDto<String>(false, 405, "缺少pageNum字段"));
        }
        if (userId==null){
            return JSONUtil.toJsonStr(new ResponseDto<String>(false, 405, "缺少userId字段"));
        }
        return JSONUtil.toJsonStr(new ResponseDto<>(blogService.getByPageById(Integer.valueOf(pageNum),Integer.valueOf(userId))));
    }
    /**
     * 删除某一条说说
     */
    @PostMapping("/delete")
    public String delete(@RequestBody String data){
        JSONObject jsonObject = JSONUtil.parseObj(data);
        //验证token是否存在或者失效
        Integer id = redisOperator.verifyToken(jsonObject.getStr("token"));
        if(id==null) {
            return JSONUtil.toJsonStr(new ResponseDto<String>(false, 404, "token失效或者未找到"));
        }
        String blogId = jsonObject.getStr("blogId");
        blogService.delete(Integer.valueOf(blogId),id);
        commentService.deleteByBlogId(Integer.valueOf(blogId));
        redisOperator.clearLikes(Integer.valueOf(blogId));
        return JSONUtil.toJsonStr(new ResponseDto<>("删除成功！"));
    }

}
