package com.dchat.service.inter;

import com.dchat.domain.UserInfo;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface FriendService {
    List<UserInfo> getFriendsById(Integer id);

    Boolean isFriend(String id1,String id2);

    void addFriend(String id1,String id2);

    void deleteFriend(String id1,String id2);
}
