package com.dchat.controller;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.dchat.domain.ResponseDto;
import com.dchat.util.RedisOperator;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import javax.servlet.http.HttpServletRequest;

@RestController
@RequestMapping("/dchat")
public class MessageController {
    @Autowired
    private RedisOperator redisOperator;

}
