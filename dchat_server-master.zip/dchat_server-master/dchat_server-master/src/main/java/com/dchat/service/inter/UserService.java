package com.dchat.service.inter;

import com.dchat.domain.User;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface UserService {
    User getUserByLoginId(String loginId);

    User getUserById(Integer id);

    void updateUserById(User user);


    @Async
    void updateAvatar(User user);

    @Async
    void insertOne(User user);

    List<User> selectByKeyword(String keyword);
}
