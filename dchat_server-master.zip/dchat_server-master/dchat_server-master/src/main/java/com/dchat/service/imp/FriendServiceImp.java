package com.dchat.service.imp;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.dchat.domain.Friend;
import com.dchat.domain.UserInfo;
import com.dchat.mapper.FriendMapper;
import com.dchat.service.inter.FriendService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;

@Service
public class FriendServiceImp implements FriendService {
    @Autowired
    private FriendMapper friendMapper;

    @Override
    public List<UserInfo> getFriendsById(Integer id) {
        return friendMapper.getFriendsById(id);
    }

    @Override
    public Boolean isFriend(String id1, String id2) {
        QueryWrapper<Friend> wrapper = new QueryWrapper<>();
        wrapper.eq("id1",id1);
        wrapper.eq("id2",id2);
        List<Friend> list = friendMapper.selectList(wrapper);
        return null != list && list.size() != 0;
    }

    @Override
    public void addFriend(String id1, String id2) {
        Date date = new Date();
        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        friendMapper.insert(new Friend(null,Integer.parseInt(id1),Integer.parseInt(id2),simpleDateFormat.format(date)));
        friendMapper.insert(new Friend(null,Integer.parseInt(id2),Integer.parseInt(id1),simpleDateFormat.format(date)));
    }

    @Override
    public void deleteFriend(String id1, String id2) {
        QueryWrapper<Friend> wrapper = new QueryWrapper<>();
        wrapper.eq("id1",id1);
        wrapper.eq("id2",id2);
        friendMapper.delete(wrapper);
        wrapper = new QueryWrapper<>();
        wrapper.eq("id1",id2);
        wrapper.eq("id2",id1);
        friendMapper.delete(wrapper);
    }
}
