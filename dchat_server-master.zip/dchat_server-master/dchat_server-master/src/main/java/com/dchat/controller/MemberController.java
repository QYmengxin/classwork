package com.dchat.controller;

import cn.hutool.json.JSONObject;
import cn.hutool.json.JSONUtil;
import com.dchat.domain.ResponseDto;
import com.dchat.domain.UserInfo;
import com.dchat.service.inter.MemberService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

@RestController
@RequestMapping("/dchat")
public class MemberController {
    @Autowired
    private MemberService memberService;

    @PostMapping("/getMember")
    public String getMember(@RequestBody String data){
        JSONObject jsonObject = JSONUtil.parseObj(data);

        List<UserInfo> list = memberService.getMemberByGroupId(jsonObject.getStr("id"));

        if(null == list){
            return JSONUtil.toJsonStr(new ResponseDto<>("not found"));
        }
        return JSONUtil.toJsonStr(new ResponseDto<>(list));
    }
}
