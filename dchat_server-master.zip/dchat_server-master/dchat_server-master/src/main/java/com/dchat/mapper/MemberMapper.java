package com.dchat.mapper;

import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import com.dchat.domain.Member;
import com.dchat.domain.UserInfo;
import org.apache.ibatis.annotations.Mapper;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface MemberMapper extends BaseMapper<Member> {
    List<UserInfo> getMemberByGroupId(String id);
}
