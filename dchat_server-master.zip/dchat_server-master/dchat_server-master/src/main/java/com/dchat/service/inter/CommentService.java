package com.dchat.service.inter;

import com.dchat.domain.Comment;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface CommentService {
    @Async
    void insert(Comment comment);
    List<Comment> getComments(Integer blogId);

    @Async
    void deleteByBlogId(Integer id);

    @Async
    void deleteById(Integer id);
}
