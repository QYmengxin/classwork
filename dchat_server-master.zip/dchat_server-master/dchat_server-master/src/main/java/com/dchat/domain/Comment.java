package com.dchat.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableField;
import com.baomidou.mybatisplus.annotation.TableId;
import com.baomidou.mybatisplus.annotation.TableName;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 评论
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@TableName("comment")
public class Comment {
    @TableId(type = IdType.AUTO)
    private Integer id;
    @TableField("blog_id")
    private Integer blogId; //说说id
    private Integer fatherId; //回复的对象 如果没有则置为-1
    @TableField("father_name")
    private String fatherName; //被回复者的昵称
    @TableField("deliver_id")
    private Integer deliverId; //发布人的id
    @TableField("deliver_name")
    private String deliverName; //发布人的昵称
    private String content;   //评论的内容
    private String time;   //评论时间
}
