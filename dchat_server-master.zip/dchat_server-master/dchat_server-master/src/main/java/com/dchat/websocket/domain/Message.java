package com.dchat.websocket.domain;

import cn.hutool.json.JSONUtil;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 封装websocket消息体
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
public class Message <T>{
    private Integer code;
    private String type;
    private T content;

    public static void main(String[] args) {
        Message<String> message = new Message<>(123,"12","dw");
        System.out.println(JSONUtil.toJsonStr(message));
    }
}
