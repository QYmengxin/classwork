package com.dchat.service.inter;

import com.dchat.domain.Grouper;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public interface GroupService {
    @Async
    void insertOne(Grouper group);

    List<Grouper> getByMemberId(Integer id);

    List<Grouper> getByKeyword(String keyword);

    @Async
    void deleteOne(String id);

    @Async
    void updateOne(Grouper grouper);
}
