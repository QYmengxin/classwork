package com.dchat.service.imp;

import com.baomidou.mybatisplus.core.conditions.query.QueryWrapper;
import com.baomidou.mybatisplus.extension.plugins.pagination.Page;
import com.dchat.domain.Blog;
import com.dchat.mapper.BlogMapper;
import com.dchat.service.inter.BlogService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

@Service
public class BlogServerImp implements BlogService {
    @Autowired
    private BlogMapper blogMapper;

    @Async
    @Override
    public void insert(Blog blog) {
        blogMapper.insert(blog);
    }

    @Override
    public Page<Blog> getByPage(Integer pageNum) {
        QueryWrapper<Blog> queryWrapper = new QueryWrapper<>();
        Page<Blog> page = new Page<>(pageNum,8);   //默认查询8条
        queryWrapper.orderByDesc("id");         //倒序
        return blogMapper.selectPage(page,queryWrapper);
    }

    @Override
    public Page<Blog> getByPageById(Integer pageNum, Integer id) {
        QueryWrapper<Blog> queryWrapper = new QueryWrapper<>();
        Page<Blog> page = new Page<>(pageNum,8);   //默认查询8条
        queryWrapper.eq("owner",id).orderByDesc("id");       //倒序
        return blogMapper.selectPage(page,queryWrapper);
    }

    @Async
    @Override
    public void delete(Integer blogId, Integer userId) {
        QueryWrapper<Blog> queryWrapper = new QueryWrapper<>();
        queryWrapper.eq("id",blogId).eq("owner",userId);
        blogMapper.delete(queryWrapper);
    }

    @Override
    public Blog getOne(Integer blogId) {
        return blogMapper.selectById(blogId);
    }


}
