package com.dchat.domain;

import com.baomidou.mybatisplus.annotation.IdType;
import com.baomidou.mybatisplus.annotation.TableId;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * 朋友圈说说
 */

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Blog {
    @TableId(type = IdType.AUTO)
    private Integer id;  //主键自增
    private Integer owner; //发布人id
    private String time;  //发布时间
    private String content; //内容
    private String images;  //图片
//    private String likes;   //点赞
}
