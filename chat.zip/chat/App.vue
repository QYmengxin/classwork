<script>
	import websocket from 'common/websocket.js';
	export default {
		onLaunch: function() {
			console.log('App Launch');
			// #ifdef APP-PLUS
			let user = this.$store.getters.token;
			if(!user){
				uni.closeSocket();
				this.$store.dispatch('clearUserInfo');
				uni.reLaunch({
					url: "/pages/index/login"
				})
			}else{
				websocket.connectSocketInit();
			}
			// #endif
			
			// #ifdef  H5
			let path = "/paths" + window.location.href.split("/pages")[1];
			let user = this.$store.getters.token;
			if(!user){
				if(path != "/pages/index/login" || path != "/pages/index/register"){
					uni.reLaunch({
						url: "/pages/index/login"
					})
				}
			}else{
				websocket.connectSocketInit();
			}
			// #endif
		},
		onShow: function() {
			console.log('App Show');
		},
		onHide: function() {
			console.log('App Hide')
		}
	}
</script>

<style lang="scss">
	/*每个页面公共css */
	.line{
		height: 20rpx;
		width: 750rpx;
		background-color: #ededed;
	}
	/*  #ifndef  APP-NVUE  */
		page{
			background-color: #ededed;
		}
	/*  #endif  */
</style>
