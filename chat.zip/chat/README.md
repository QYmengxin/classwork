# dchat_web

#### 介绍
dchat前端项目

#### 软件架构
软件架构说明


#### 安装教程
需要更改的地方 如下:

再api/url.js中修改 url  和图片长传密码

- const url = ''
- 
- //图片接口密码
- function getImagePassword() {
-   return '***';
- }
- 

注意上传图片的服务端源码在这里 
[图片服务器](https://gitee.com/derekerrr/images.git)



