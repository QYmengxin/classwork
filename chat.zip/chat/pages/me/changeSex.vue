<template>
	<view>
		<view class="container">
			<view class="row" @tap="changeGender('男')">
				<view class="gender">男</view>
				<view  v-if="sex=='男'">√</view>
			</view>
			<view class="row" @tap="changeGender('女')">
				<view class="gender">女</view>
				<view v-if="sex=='女'">√</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {updateUserInfo} from 'api/user';
	import {mapGetters,mapActions} from 'vuex';
	export default {
		data() {
			return {
				sex: this.$store.state.userInfo.gender
			}
		},

		methods: {
			...mapActions(['updateGender']),
			async changeGender(sex) {
				const { content: res } = await updateUserInfo({
				 token:this.$store.getters.token,
				 gender:sex
			  });
			  // 解析后端传送过来的json对象
			  console.log(res);
			  // 保存到vuex中，通过commit
			  this.updateGender(sex);	
			  this.sex = sex;
			  uni.showToast({
					title:"修改成功！"
			  })
			},
		}
	}
</script>

<style scoped>
	.container{
		padding-top: 40rpx;
		/* display: flex; */
		align-items: center;
		justify-content: center;
	}
	.row{
		margin-bottom: 20rpx;
		border-radius: 20rpx;
		background-color: #C0C0C0;
		line-height: 100rpx;
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.row .gender{
		font-weight: 1000;
		width: 90%;
		float: left;
		display: flex;
	}
	.text{
		font-size: large;
	}
	.btn{
		margin-top: 30rpx;
		background-color: #4CD964;
	}
</style>
