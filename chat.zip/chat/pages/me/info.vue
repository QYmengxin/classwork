<template>
	<view>
		<view class="container">
			<view class="row" @tap="changeAvatar()">
				<view class="content">
					<text class="title">头像</text>
					<view class="avatar_container">
						<image class="avatar" :src="avatar==''?'https://s2.loli.net/2022/05/04/gWjFMmZxJIbsz7G.png':avatar"></image>
					</view>
					<text class="arrow">></text>
				</view>
			</view>
			
			<view class="row">
				<view class="content">
					<text class="title">D id</text>
					<view class="avatar_container">
						<text class="text">{{id}}</text>
					</view>
				</view>
			</view>
			
			<view class="row" @tap="changeName()">
				<view class="content">
					<text class="title">昵称</text>
					<view class="avatar_container">
						<text class="text">{{nickname}}</text>
					</view>
					<text class="arrow">></text>
				</view>
			</view>
			
			<view class="row" @tap="changeSex()">
				<view class="content">
					<text class="title">性别</text>
					<view class="avatar_container">
						<text class="text">{{gender}}</text>
					</view>
					<text class="arrow">></text>
				</view>
			</view>
			
			<view class="row" @tap="changeSig()">
				<view class="content">
					<text class="title">个性签名</text>
					<view class="avatar_container">
						<text class="text">{{sig}}</text>
					</view>
					<text class="arrow">></text>
				</view>
			</view>
		</view>
	
		<view class="bottom">
			<button class="logoutBtn" @click="logout()">退出登录</button>
		</view>
	</view>
</template>

<script>
	import {mapGetters,mapMutations,mapActions} from 'vuex';
	export default {
		data() {
			return {
				sig: this.$store.state.userInfo.signature
			}
		},
		onLoad() {
			if(this.sig.length>=10){
				this.sig = this.sig.substr(0,10)+"...";
			}
		},
		//通过计算属性可以读取并实时监听状态的变化
		computed: {
		  ...mapGetters(['avatar','nickname','id','gender']),
		},
		methods: {
			...mapActions(['clearUserInfo']),
			changeName(){
				uni.navigateTo({
					url:'changeName',
					animationType:'slide-in-right',
				})
			},
			changeSig(){
				uni.navigateTo({
					url:'changeSig',
					animationType:'slide-in-right',
				})
			},
			changeSex(){
				uni.navigateTo({
					url:'changeSex',
					animationType:'slide-in-right',
				})
			},
			///头像
			changeAvatar: function() {
				uni.navigateTo({
					url:'changeAvatar',
					animationType:'slide-in-right',
				})
			},
			//退出登录
			logout(){
				let that = this;
				uni.showModal({
					title:'提示',
					content:'确定退出登录',
					confirmText:'确定',
					confirmColor:'#D94B4D',
					cancelText:'取消',
					success: (res) => {
						if(res.confirm){
							that.clearUserInfo();
							uni.reLaunch({
								url:'../index/login'
							})
						}
					}
				})
			}
		}
	}
</script>

<style scoped>
	.container{
		padding-top: 20rpx;
		/* display: flex; */
		align-items: center;
		justify-content: center;
	}
	.title{
		margin: auto;
		margin-left: 15rpx;
		color: #8F8F94;
		font-size: 100%;
		font-weight: 600;
	}
	.arrow{
		margin-top: auto;
		margin-bottom: auto;
		color: #8F8F94;
		margin-right: 5rpx;
		margin-left: 20rpx;
		font-weight: 600;
	}
	.avatar_container{
		margin-left: auto;
		margin-right: 0;
	}
	.avatar{
		width: 120rpx;
		height: 120rpx;
		border-radius: 20rpx;
	}
	.row{
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.row .content{
		line-height: 120rpx;
		width: 90%;
		float: left;
		display: flex;
		border-bottom-color: #C8C7CC;
		border-bottom-style: inset;
	}
	.text{
		margin-right: 20rpx;
		font-weight: 900;
	}
	.bottom{
		bottom: 40rpx;
		position: fixed;
		width: 100%;

	}
	.logoutBtn{
		margin: auto;
		background-color: red;
		color: white;
		margin-left: 20rpx;
		margin-right: 20rpx;
	}
</style>
