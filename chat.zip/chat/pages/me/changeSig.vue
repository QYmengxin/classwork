<template>
	<view>
		<view class="container">
			<view class="row">
				<view class="content">
					<textarea class="text" v-model="sig"  placeholder="输入个性签名"/>
				</view>
			</view>
			<view class="row">
				<button class="btn" @tap="changeSignature()">修改</button>
			</view>
		</view>
	</view>
</template>

<script>
	import {updateUserInfo} from 'api/user';
	import {mapGetters,mapActions} from 'vuex';
	export default {
		data() {
			return {
				sig: this.$store.state.userInfo.signature
			}
		},
		methods: {
			...mapActions(['updateSignature']),
			async changeSignature() {
				const { content: res } = await updateUserInfo({
				 token:this.$store.getters.token,
				 signature:this.sig
			  });
			  // 解析后端传送过来的json对象
			  console.log(res);
			  // 保存到vuex中，通过commit
			  this.updateSignature(this.sig);	
			  uni.showToast({
					title:"修改成功！"
			  })
			},
		},
		
	}
</script>

<style scoped>
	.container{
		padding-top: 40rpx;
		/* display: flex; */
		align-items: center;
		justify-content: center;
	}
	.row{
		display: flex;
		align-items: center;
		justify-content: center;
	}
	.row .content{
		line-height: 300rpx;
		width: 90%;
		float: left;
		display: flex;
		border-bottom-color: #8F8F94;
		border-bottom-style: inset;
	}
	.text{
		font-size: large;
	}
	.btn{
		margin-top: 30rpx;
		background-color: #4CD964;
	}
</style>
