<template>
	<view>
		<view class="container">
			<view class="item" v-for="(image,index) in images" :key="index">
				<image class="image" :src="image.url" @tap="change(image.url)"></image>
				<view class="name-container">
					<text class="name">{{image.name}}</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {mapActions} from 'vuex';
	export default {
		data() {
			return {
				images:[
					{
						url:'/static/icon/bg-1.jpg',
						name:'幽竹小径'
					},
					{
						url:'/static/icon/bg-2.jpg',
						name:'淡紫远山'
					},
					{
						url:'/static/icon/bg-3.jpg',
						name:'暮色夕阳'
					},
					{
						url:'/static/icon/bg-4.jpg',
						name:'仲夏梦莲'
					}
					
				]
			}
		},
		methods: {
			...mapActions(['setWorldBg']),
			change(url){
				this.setWorldBg(url);
			}
		}
	}
</script>

<style scoped>
	.container{
		display: grid;
		grid: auto / auto auto;
	}
	.name-container{
		text-align: center;
	}
	.item{
		
	}
	.image{
		margin: 20rpx;
		width: 90%;
		height: 200rpx;
		border-radius: 20rpx;
		
	}
</style>
