<template>
	<view>
		<view class="item">
			<view class="container" @tap="toZoomPage()">
				<view class="avatar-container">
					<image class="avatar"  src="/static/icon/selected_space.svg"></image>
				</view>
				<view class="content">
					<text class="name">世界</text>
				</view>
				<text class="arrow">></text>
			</view>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		onNavigationBarButtonTap: (button) => {
			if(button.index==0){
				uni.navigateTo({
					url:'../other/search/search',
					animationType:'slide-in-right'
				})
			}
		},
		methods: {
			toZoomPage(){
				uni.navigateTo({
					url:'zoom/zoom',
					animationType:'slide-in-right'
				})
			}
		}
	}
</script>

<style scoped>
	.arrow{
		margin-top: auto;
		margin-bottom: auto;
		color: #8F8F94;
		margin-right: 5rpx;
		margin-left: 20rpx;
		font-weight: 600;
	}
	.item{
		border-radius: 15rpx;
		/* background-color: rgb(200,199,204); */
	}
	.item :hover{
		border-radius: 15rpx;
		background-color: rgb(200,199,204); 
	}
	.container{
		border-radius: 30rpx;
		width: 100%;
		display: flex;
		margin-top: 10rpx;
		background-color: #e1e1e1;
	}

	.avatar-container{
		position: relative;
		margin: 10rpx;
	}
	.avatar{
		width: 110rpx;
		height: 110rpx;
		border-radius: 20rpx;
	}
	.content{
		display: flex;
		align-items: auto;
		flex-direction: column;
		justify-content: center;
		padding-left: 10rpx;
	}
	.name{
		text-align: left;
		margin-top: 0;
		font-weight: 1000;
		font-size: large;
	}
</style>
