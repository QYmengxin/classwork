<template>
	<view>
		<view class="item">
			<view class="container" @tap="toApplyPage()">
				<view class="avatar-container">
					<image class="avatar"  src="/static/icon/add.svg"></image>
					<text class="unchecked" v-show="applyList.length>0">{{applyList.length}}</text>
				</view>
				<view class="content">
					<text class="name">新的朋友</text>
				</view>
				<text class="arrow">></text>
			</view>
			<view class="container" @tap="toGroupPage()">
				<view class="avatar-container">
					<image class="avatar"  src="/static/icon/group.svg"></image>
				</view>
				<view class="content">
					<text class="name">我的群聊</text>
				</view>
				<text class="arrow">></text>
			</view>
			<view class="divider">
				<text class="divider-text">我的好友</text>
			</view>
			<view class="container" v-for="(friend,index) in friends" :key="friend.id" @longpress="removeFriend(index)" @tap="toFriendInfo(index)">
				<view class="avatar-container">
					<image class="avatar"  :src="friend.avatar"></image>
				</view>
				<view class="content">
					<text class="name">{{friend.nickname}}</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import WebSocket from '@/common/websocket.js';
	import {mapGetters,mapActions} from 'vuex'
	import $store from '@/store/index.js';
	export default {
		data() {
			return {
				
			}
		},
		onNavigationBarButtonTap: (button) => {
			if(button.index==0){
				uni.navigateTo({
					url:'../other/search/search',
					animationType:'slide-in-right',
				})
			}
		},
		//通过计算属性可以读取并实时监听状态的变化
		computed: {
		   ...mapGetters(['friends','applyList','user']),
		},
		//刷新列表
		onPullDownRefresh() {
			$store.dispatch('setFriendList');
			uni.showToast({
				title:'刷新列表成功！',
				icon:'success'
			})
			uni.stopPullDownRefresh();
		},
		methods: {
			...mapActions(['deleteFriend']),
			toGroupPage(){
				uni.navigateTo({
					url:'group/group',
					animationType:'slide-in-right'
				})
			},
			toApplyPage(){
				uni.navigateTo({
					url:'apply/apply',
					animationType:'slide-in-right'
				})
			},
			//进入好友详情页
			toFriendInfo(index){
				uni.navigateTo({
					url:'info/info?index='+index
				})
			},
			removeFriend(index){
				let that = this;
				uni.showModal({
					title:'删除好友',
					confirmText:'确定',
					cancelText:'取消',
					confirmColor:'#D94B4D',
					content:'聊天记录不会保存',
					success:function(res){
						if(res.confirm){
							//构造消息
							let message = {
								type:'delete-person',
								from: that.user.id,
								to: that.friends[index].id
							}
							WebSocket.sendMessage(message);
							
							that.deleteFriend(index);
						}
					}
				})
			},
		}
	}
</script>

<style scoped>
	.unchecked{
		display: block;
		width: 40rpx; height: 40rpx;
		background-color: red; color: white;
		font-size:medium;
		text-align: center; line-height: 40rpx;
		border-radius: 50%;
		position: absolute; right: -10px; top: -10rpx;
	}
	.arrow{
		margin-top: auto;
		margin-bottom: auto;
		color: #8F8F94;
		margin-right: 5rpx;
		margin-left: 20rpx;
		font-weight: 600;
	}
	.divider{
		margin-top: 10rpx;
		padding-left: 20rpx;
		background-color: #c5c3c4;
		border-radius: 10rpx;
	}
	.divider-text{
		font-size: smaller;
	}
	.item{
		border-radius: 15rpx;
		/* background-color: rgb(200,199,204); */
	}
	.item :hover{
		border-radius: 15rpx;
		background-color: rgb(200,199,204); 
	}
	.container{
		border-radius: 30rpx;
		width: 100%;
		display: flex;
		margin-top: 10rpx;
		background-color: #e1e1e1;
	}

	.avatar-container{
		position: relative;
		margin: 10rpx;
	}
	.avatar{
		width: 110rpx;
		height: 110rpx;
		border-radius: 20rpx;
	}
	.content{
		display: flex;
		align-items: auto;
		flex-direction: column;
		justify-content: center;
		padding-left: 10rpx;
	}
	.name{
		text-align: left;
		margin-top: 0;
		font-weight: 1000;
		font-size: large;
	}
</style>
