<template>
	<view>
		<view class="item">
			<view class="divider">
				<text class="divider-text">我的群聊</text>
			</view>
			<view class="container" v-for="(group,index) in groups" :key="group.id" @tap="toInfoPage(index)">
				<view class="avatar-container">
					<image class="avatar"  :src="group.avatar"></image>
				</view>
				<view class="content">
					<text class="name">{{group.name}}</text>
				</view>
			</view>
		</view>
	</view>
</template>

<script>
	import {mapGetters} from 'vuex';
	import $store from '@/store/index.js';
	export default {
		data() {
			return {
			
			}
		},
		onNavigationBarButtonTap: () => {
			uni.navigateTo({
				url:'create',
				animationType:'slide-in-right',
			})
		},
		computed:{
			...mapGetters(['groups']),
		},
		//刷新列表
		onPullDownRefresh() {
			$store.dispatch('getGroupList');
			uni.showToast({
				title:'刷新列表成功！',
				icon:'success'
			})
			uni.stopPullDownRefresh();
		},
		methods: {
			toInfoPage(index){
				uni.navigateTo({
					url:'./info?index='+index,
					animationType:'slide-in-right'
				})
			}
		}
	}
</script>

<style scoped>
	.arrow{
		margin-top: auto;
		margin-bottom: auto;
		color: #8F8F94;
		margin-right: 5rpx;
		margin-left: 20rpx;
		font-weight: 600;
	}
	.divider{
		margin-top: 10rpx;
		padding-left: 20rpx;
		background-color: #c5c3c4;
		border-radius: 10rpx;
	}
	.divider-text{
		font-size: smaller;
	}
	.item{
		border-radius: 15rpx;
		/* background-color: rgb(200,199,204); */
	}
	.item :hover{
		border-radius: 15rpx;
		background-color: rgb(200,199,204); 
	}
	.container{
		border-radius: 30rpx;
		width: 100%;
		display: flex;
		margin-top: 10rpx;
		background-color: #e1e1e1;
	}
	
	.avatar-container{
		position: relative;
		margin: 10rpx;
	}
	.avatar{
		width: 110rpx;
		height: 110rpx;
		border-radius: 50%;
	}
	.content{
		display: flex;
		align-items: auto;
		flex-direction: column;
		justify-content: center;
		padding-left: 10rpx;
	}
	.name{
		text-align: left;
		margin-top: 0;
		font-weight: 1000;
		font-size: large;
	}
</style>
