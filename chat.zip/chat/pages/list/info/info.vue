<template>
    <div class="mine">
        <div class="top">
            <image :src="friends[index].avatar" @tap="showPic(friends[index].avatar)"></image>
            <view class="name">{{friends[index].nickname}}</view>
        </div>
		<view class="middle">
			<view class="row">
				<text class="title">D id</text>
				<text class="content">{{friends[index].loginId}}</text>
			</view>
			<view class="row">
				<text class="title">性别</text>
				<text class="content">{{friends[index].gender==''?'未知':friends[index].gender}}</text>
			</view>
			<view class="row">
				<text class="title">个性签名</text>
				<text class="content">{{friends[index].signature!=''?friends[index].signature:'这个人很懒,什么也没有留下...'}}</text>
			</view>
			<view class="row">
				<text class="title">注册时间</text>
				<text class="content">{{friends[index].registerTime!=''?friends[index].registerTime:'不得而知...'}}</text>
			</view>
		</view>
        <div class="bottom">
			<button class="btn" @tap="toChatRoom()">发消息</button>
        </div>
    </div>
</template>

<script>
	import util from 'util/date';
	import {mapGetters,mapActions} from 'vuex';
    export default {
        data () {
            return {
				index: 0
            }
        },
		onLoad (options) {
			this.index = options.index;
		},
		//通过计算属性可以读取并实时监听状态的变化
		computed: {
		   ...mapGetters(['friends']),
		},
        methods : {
		  ...mapActions(['getRoomIndex','createNewChatRoom']),
		  // 预览图片
		 showPic(url) {
		 	uni.previewImage({
		 		indicator: 'none',
		 		current:url,
		 		urls:[url]
		 	});
		 },
          async toChatRoom(){
			let i;
			i = await this.getRoomIndex(this.friends[this.index].id);
			//如果没有会话窗口 就新建一个
			if(i==-1){
				let time = util.getTimeNow();
				let data = {
					id:this.friends[this.index].id,
					nickname:this.friends[this.index].nickname,
					avatar:this.friends[this.index].avatar,
					time:time
				}
				await this.createNewChatRoom(data);
				i = await this.getRoomIndex(this.friends[this.index].id);
			}
			uni.navigateTo({
				url:'../../chat/chatRoom/chatRoom?index='+i,
			})
		  }
            
        }
    }
</script>

<style>
	.row{
		display: flex;
	}
	.middle{
		padding: 20rpx;
	}
	.title{
		font-weight: 600;
		border-radius: 10rpx;
		padding: 5rpx;
		background-color: #c2b5be;
		margin: 10rpx;
	}
	.content{
		font-weight: 500;
		margin-top: 10rpx;
		margin-left: 20rpx;
	}
    .mine{
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    .top{
        height: 400rpx;
        background: #C8C7CC;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }
    .top image{
        width:156rpx;
        height: 156rpx;
        border-radius: 156rpx;
    }
    .top .name{
		font-weight: 1000;
		font-size: larger;
        line-height: 80rpx;
    }
    .bottom{
		padding-top: 100rpx;
        text-align: center;
        line-height: 200rpx;
    }
	.logout{
		width: 266rpx;
		height: 76rpx;
		line-height: 76rpx;
		margin: 0 auto;
		background-color: #618DFF;
		border-radius: 10rpx;
		color: #FFFFFF;
		font-size: 32rpx;
	}
	.btn{
		background-color: #4CD964;
		color: white;
		margin: 20rpx;
		border-radius: 15rpx;
	}
</style>
