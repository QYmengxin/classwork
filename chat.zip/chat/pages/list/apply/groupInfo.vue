<template>
    <div class="mine">
        <div class="top">
            <image :src="group.avatar"></image>
            <view class="name">{{group.name}}</view>
        </div>
		<view class="middle">
			<view class="row">
				<text class="title">群id</text>
				<text class="content">{{group.id}}</text>
			</view>
			<view class="row">
				<text class="title">群简介</text>
				<text class="content">{{group.introduction}}</text>
			</view>
			<view class="container" @tap="toMemberPage(group.id,group.ownerId)">
				<view class="content">
					<text class="name">群成员</text>
				</view>
				<text class="arrow">></text>
			</view>
		</view>
        <div class="bottom">
			<button class="btn" @tap="applyToJoin()">申请入群</button>
        </div>
    </div>
</template>

<script>
	import WebSocket from '@/common/websocket.js';
	import $store from '@/store/index.js';
	import util from 'util/date';
	import {mapGetters,mapActions} from 'vuex';
	import dateUtil from '@/util/date.js';
    export default {
        data () {
            return {
				group:{}
            }
        },
		onLoad (options) {
			this.group = this.applyList[options.index].group;
		},
		//通过计算属性可以读取并实时监听状态的变化
		computed:{
			...mapGetters(['applyList','user']),
		},
        methods : {
		  ...mapActions(['getRoomIndex','createNewChatRoom']),
          
		  toMemberPage(id,owner_id){
			  uni.navigateTo({
				url:'member?id='+id+'&owner_id='+owner_id,
				animationType:'slide-in-right'
			  })
		  },
		  //申请入群
		  applyToJoin(){
			  //构造消息
			  let message={
			  	type:'apply-group',
			  	to:this.group.ownerId,
				group:this.group,
			  	from:this.$store.getters.user,
			  	time:dateUtil.getTimeNow()
			  }
			  WebSocket.sendMessage(message);
		  }
            
        }
    }
</script>

<style>
	.row{
		display: flex;
	}
	.middle{
		padding: 20rpx;
	}
	.title{
		font-weight: 600;
		border-radius: 10rpx;
		padding: 5rpx;
		background-color: #c2b5be;
		margin: 10rpx;
	}
	.content{
		font-weight: 500;
		margin-top: 10rpx;
		margin-left: 20rpx;
		word-break:break-all;
	}
    .mine{
        width: 100%;
        height: 100%;
        display: flex;
        flex-direction: column;
    }
    .top{
        height: 400rpx;
        background: #C8C7CC;
        display: flex;
        flex-direction: column;
        justify-content: center;
        align-items: center;
    }
    .top image{
        width:156rpx;
        height: 156rpx;
        border-radius: 156rpx;
    }
    .top .name{
		font-weight: 1000;
		font-size: larger;
        line-height: 80rpx;
    }
    .bottom{
		padding-top: 100rpx;
        text-align: center;
        line-height: 200rpx;
    }
	.logout{
		width: 266rpx;
		height: 76rpx;
		line-height: 76rpx;
		margin: 0 auto;
		background-color: #618DFF;
		border-radius: 10rpx;
		color: #FFFFFF;
		font-size: 32rpx;
	}
	.btn{
		margin-top: 50rpx;
		background-color: #4CD964;
		color: white;
		margin: 20rpx;
		border-radius: 15rpx;
	}
	.container{
		border-radius: 30rpx;
		width: 100%;
		display: flex;
		margin-top: 10rpx;
		background-color: #e1e1e1;
		line-height: 100rpx;
	}
	.container .content{
		display: flex;
		align-items: auto;
		flex-direction: column;
		justify-content: center;
		padding-left: 10rpx;
	}
	.container .content .name{
		text-align: left;
		margin-top: 0;
		font-weight: 1000;
		font-size: large;
	}
	.arrow{
		margin-top: auto;
		margin-bottom: auto;
		color: #8F8F94;
		margin-right: 20rpx;
		margin-left: auto;
		font-weight: 600;
	}
	.red{
		background-color: #ff0000;
	}
	.blue{
		background-color: #00aaff;
	}
</style>
